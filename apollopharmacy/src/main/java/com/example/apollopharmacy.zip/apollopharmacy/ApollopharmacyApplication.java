package com.example.apollopharmacy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApollopharmacyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApollopharmacyApplication.class, args);
	}

}
